/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.rnacalculopesos;

import java.util.Arrays;

/**
 *
 * @author geronimo
 */
public class main {

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    double pesosInit[][] = {
      {0.237730123, 0.220753095, 0.121696911},
      {0.517252421, -0.525871273, 0.889138332},
      {-0.007687743, -0.48985644, -0.661022759}
    };

    double nHidden = 2, nInput = 2;

    System.out.println("Pesos Iniciales");
    imprimir(pesosInit);
    System.out.println("\nPesos Ajustados");
    imprimir(NguyenWidrow(pesosInit, nHidden, nInput));
  }

  public static double[][] NguyenWidrow(double pesosInit[][], double nHidden, double nInput) {
    /*Variables requeridas*/
    double pesosAjustados[][] = pesosInit;
    int lengthPesos = pesosInit.length;
    double normHidden[] = new double[lengthPesos - 1];
    double sum = 0;

    /*Paso #1 Calculo de beta*/
    double beta = 0.7 * Math.pow(nHidden, (1 / nInput));

    /*Paso #2 Calcule de Eucliden Norm*/
    for (int i = 1; i < lengthPesos; i++) {
      sum = 0;
      for (int j = 0; j < pesosInit[i].length; j++) {
        sum += Math.pow(pesosInit[i][j], 2);
      }
      normHidden[i - 1] = Math.sqrt(sum);
    }
    /*Paso #3 Ajuste de pesos*/
    for (int i = 1; i < lengthPesos; i++) {
      for (int j = 0; j < pesosInit[i].length; j++) {
        pesosAjustados[i][j] = (beta * pesosInit[i][j]) / normHidden[i - 1];
      }
    }

    return pesosAjustados;
  }

  public static void imprimir(double a[][]) {
    for (int row = 0; row < a.length; row++) {
      for (int col = 0; col < a[row].length; col++) {
        System.out.printf(" %3.10f ", a[row][col]);
      }
      System.out.print("\n");
    }
  }

  public static void imprimir(double a[]) {
    for (int row = 0; row < a.length; row++) {
      System.out.printf(" %3.10f ", a[row]);
    }
  }
}
