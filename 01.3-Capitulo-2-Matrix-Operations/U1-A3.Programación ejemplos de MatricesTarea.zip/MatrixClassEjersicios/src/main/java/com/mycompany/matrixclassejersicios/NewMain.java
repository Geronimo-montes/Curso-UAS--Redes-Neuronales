/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.matrixclassejersicios;

import matrix.Matrix;
import matrix.BiPolarUtil;
import matrix.MatrixMath;

import java.util.Scanner;

/**
 *
 * @author geronimo
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        while (true) {
            System.out.printf("\nElija una opcion:\n1)Suma"
                    + "\n2)Resta\n3)Divicion entre Escalar"
                    + "\n4)Product Punto\n5)Multiplicacion"
                    + "\n6)Multiplicacion por Escalar"
                    + "\n7)Multiplicacion por Matriz Identidad"
                    + "\n8)Matriz Traspuesta"
                    + "\n9)Bipolar\n10)Magnitud\n"
                    + ">10) Salir\n");
            Scanner entradaEscaner = new Scanner(System.in); //Creación de un objeto Scanner
            switch (Integer.parseInt(entradaEscaner.nextLine())) {
                case 1 ->
                    suma();
                case 2 ->
                    resta();
                case 3 ->
                    divicionEscalar();
                case 4 ->
                    prodPunto();
                case 5 -> {
                    multiplicacionMatrix();
                    System.out.print("\n\n");
                    multiplicacionMatrix2();
                }
                case 6 ->
                    multiplicacionEscalar();
                case 7 ->
                    multiplicacionMatrixIdentidad();
                case 8 -> {
                    double matriz[][] = {
                        {1.0, 2.0},
                        {3.0, 4.0},
                        {5.0, 6.0}
                    };

                    Matrix m = new Matrix(matriz);
                    imprimir(m);
                    System.out.print("\n\n");
                    m = MatrixMath.transpose(m);
                    imprimir(m);
                }
                case 9 -> {
                    System.out.print("\nMatriz bipolar\n");
                    boolean booleanData2[][] = {{true, false}, {false, true}};
                    Matrix matriz2 = new Matrix(BiPolarUtil.bipolar2double(booleanData2));
                    imprimir(matriz2);
                }
                case 10 -> {
                    double matriz[] = {1.0, 1.0};
                    System.out.println(MatrixMath.vectorLength(Matrix.createColumnMatrix(matriz)));
                }
                default ->
                    System.exit(0);
            }
        }
    }

    public static void suma() {
        double matrizData1[][] = {
            {1.0, 2.0},
            {3.0, 4.0},
            {3.0, 4.0},};

        double matrizData2[][] = {
            {4.0, 5.0},
            {6.0, 7.0}
        };

        Matrix matrix1 = new Matrix(matrizData1);
        Matrix matrix2 = new Matrix(matrizData2);

        System.out.print("Suma de Matrizes....\n");

        Matrix matrixData = MatrixMath.add(matrix1, matrix2);

        imprimir(matrix1);
        System.out.print("+\n");
        imprimir(matrix2);
        System.out.print("=\n");
        for (int row = 0; row < matrix1.getRows(); row++) {
            for (int col = 0; col < matrix1.getCols(); col++) {
                System.out.printf("  %2.2f + %2.2f  ",
                        matrix1.get(row, col), matrix2.get(row, col));
                if (col == matrix1.getCols() - 1) {
                    System.out.print("\n");
                }
            }
        }
        System.out.print("=\n");
        imprimir(matrixData);
    }

    public static void resta() {
        double matrizData1[][] = {
            {1.0, 2.0},
            {3.0, 4.0}
        };

        double matrizData2[][] = {
            {4.0, 5.0},
            {6.0, 7.0}
        };

        Matrix matrix1 = new Matrix(matrizData1);
        Matrix matrix2 = new Matrix(matrizData2);

        System.out.print("Suma de Matrizes....\n");

        Matrix matrixData = MatrixMath.subtract(matrix2, matrix1);

        imprimir(matrix1);
        System.out.print("+\n");
        imprimir(matrix2);
        System.out.print("=\n");
        for (int row = 0; row < matrix1.getRows(); row++) {
            for (int col = 0; col < matrix1.getCols(); col++) {
                System.out.printf("  %2.2f - %2.2f  ",
                        matrix2.get(row, col), matrix1.get(row, col));
                if (col == matrix1.getCols() - 1) {
                    System.out.print("\n");
                }
            }
        }
        System.out.print("=\n");
        imprimir(matrixData);
    }

    public static void divicionEscalar() {
        double matrizData1[][] = {
            {2.0, 4.0},
            {6.0, 8.0}
        };

        Matrix matrix1 = new Matrix(matrizData1);
        System.out.print("Divicion de Matrizes....\n");

        Matrix matrixData = MatrixMath.divide(matrix1, 2);

        imprimir(matrix1);
        System.out.print("  /\n 2\n");
        System.out.print("  =\n");
        for (int row = 0; row < matrix1.getRows(); row++) {
            for (int col = 0; col < matrix1.getCols(); col++) {
                System.out.printf(" %2.2f / 2  ",
                        matrix1.get(row, col));
                if (col == matrix1.getCols() - 1) {
                    System.out.print("\n");
                }
            }
        }
        System.out.print("  =\n");
        imprimir(matrixData);
    }

    public static void multiplicacionEscalar() {
        double matrizData1[][] = {
            {1.0, 2.0, 3.0},
            {4.0, 5.0, 6.0},
            {7.0, 8.0, 9.0}
        };

        Matrix matrix1 = new Matrix(matrizData1);
        System.out.print("Multiplicacion de Matriz por escalar....\n");

        Matrix matrixData = MatrixMath.multiply(matrix1, 2);

        imprimir(matrix1);
        System.out.print("  /\n 2\n");
        System.out.print("  =\n");
        for (int row = 0; row < matrix1.getRows(); row++) {
            for (int col = 0; col < matrix1.getCols(); col++) {
                System.out.printf(" %2.2f * 2  ",
                        matrix1.get(row, col));
                if (col == matrix1.getCols() - 1) {
                    System.out.print("\n");
                }
            }
        }
        System.out.print("  =\n");
        imprimir(matrixData);
    }

    public static void prodPunto() {
        double matrizData1[] = {1.0, 2.0, 3.0, 4.0};

        double matrizData2[] = {5.0, 6.0, 7.0, 8.0};

        Matrix matrix1 = Matrix.createRowMatrix(matrizData1);
        Matrix matrix2 = Matrix.createColumnMatrix(matrizData2);

        System.out.print("Produco Punto de Matrizes....\n");

        double _prodPunto = MatrixMath.dotProduct(matrix1, matrix2);

        imprimir(matrix1);
        System.out.print("  *\n");
        imprimir(matrix2);
        System.out.print("  =\n");
        for (int row = 0; row < matrix1.getRows(); row++) {
            for (int col = 0; col < matrix1.getCols(); col++) {
                System.out.printf(" %2.2f * %2.2f  ",
                        matrix1.get(row, col), matrix2.get(col, row));
                if (col == matrix1.getCols() - 1) {
                    System.out.print("\n");
                }
            }
        }
        System.out.printf("  =\n %2.2f", _prodPunto);
    }

    public static void multiplicacionMatrix() {
        double matrizData1[][] = {
            {1.0, 4.0},
            {2.0, 5.0},
            {3.0, 6.0},};

        double matrizData2[][] = {
            {7.0, 8.0, 9.0},
            {10.0, 11.0, 12.0}
        };

        Matrix matrix1 = new Matrix(matrizData1);
        Matrix matrix2 = new Matrix(matrizData2);

        System.out.print("Multiplicacion de Matrizes....\n");

        Matrix matrix = MatrixMath.multiply(matrix1, matrix2);

        imprimir(matrix1);
        System.out.print("  *\n");
        imprimir(matrix2);
        System.out.print("  =\n");
        for (int row = 0; row < matrix1.getRows(); row++) {
            for (int _col = 0; _col < matrix2.getCols(); _col++) {
                System.out.printf(" (%2.2f * %2.2f) + (%2.2f * %2.2f) ",
                        matrix1.get(row, 0), matrix2.get(0, _col),
                        matrix1.get(row, 1), matrix2.get(1, _col));
                if (_col == matrix2.getCols() - 1) {
                    System.out.print("\n");
                }
            }
        }
        System.out.print("  =\n");
        imprimir(matrix);
    }

    public static void multiplicacionMatrix2() {
        double matrizData1[][] = {
            {1.0, 4.0},
            {2.0, 5.0},
            {3.0, 6.0},};

        double matrizData2[][] = {
            {7.0, 8.0, 9.0},
            {10.0, 11.0, 12.0}
        };

        Matrix matrix1 = new Matrix(matrizData1);
        Matrix matrix2 = new Matrix(matrizData2);

        System.out.print("Multiplicacion de Matrizes....\n");

        Matrix matrix = MatrixMath.multiply(matrix2, matrix1);

        imprimir(matrix2);
        System.out.print("  *\n");
        imprimir(matrix1);
        System.out.print("  =\n");
        for (int row = 0; row < matrix2.getRows(); row++) {
            for (int _col = 0; _col < matrix1.getCols(); _col++) {
                System.out.printf(" (%2.2f * %2.2f) + (%2.2f * %2.2f) + (%2.2f * %2.2f)  ",
                        matrix2.get(row, 0), matrix1.get(0, _col),
                        matrix2.get(row, 1), matrix1.get(1, _col),
                        matrix2.get(row, 2), matrix1.get(2, _col));
                if (_col == matrix1.getCols() - 1) {
                    System.out.print("\n");
                }
            }
        }
        System.out.print("  =\n");
        imprimir(matrix);
    }

    public static void multiplicacionMatrixIdentidad() {
        double matrizData1[][] = {
            {1.0, 2.0, 3.0},
            {4.0, 5.0, 6.0},
            {7.0, 8.0, 9.0},};
        double matrizData2[][] = {
            {1.0, 0.0, 0.0},
            {0.0, 1.0, 0.0},
            {0.0, 0.0, 1.0},};

        Matrix matrix1 = new Matrix(matrizData1);
        Matrix matrix2 = new Matrix(matrizData2);

        System.out.print("Multiplicacion de Matrizes....\n");

        Matrix matrix = MatrixMath.multiply(matrix1, matrix2);

        imprimir(matrix1);
        System.out.print("  *\n");
        imprimir(matrix2);
        System.out.print("  =\n");
        for (int row = 0; row < matrix1.getRows(); row++) {
            for (int _col = 0; _col < matrix2.getCols(); _col++) {
                System.out.printf(" (%2.2f * %2.2f) + (%2.2f * %2.2f) ",
                        matrix1.get(row, 0), matrix2.get(0, _col),
                        matrix1.get(row, 1), matrix2.get(1, _col));
                if (_col == matrix2.getCols() - 1) {
                    System.out.print("\n");
                }
            }
        }
        System.out.print("  =\n");
        imprimir(matrix);
    }

    public static void imprimir(Matrix a) {
        for (int row = 0; row < a.getRows(); row++) {
            for (int col = 0; col < a.getCols(); col++) {
                System.out.printf(" %2.2f ", a.get(row, col));
                if (col == a.getCols() - 1) {
                    System.out.print("\n");
                }
            }
        }
    }

}
