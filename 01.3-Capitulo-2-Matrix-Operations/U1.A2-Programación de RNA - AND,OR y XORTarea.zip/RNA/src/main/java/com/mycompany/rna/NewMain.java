    /*
     * To change this license header, choose License Headers in Project Properties.
     * To change this template file, choose Tools | Templates
     * and open the template in the editor.
     */
    package com.mycompany.rna;

    /**
     *
     * @author geronimo
     */
    public class NewMain {

        /**
         * @param args the command line arguments
         */
        public static void main(String[] args) {
            System.out.print("Hola mundo");

            int entrada[][] = {
                {0, 0},
                {0, 1},
                {1, 0},
                {1, 1}
            };


            int rnaAND[] = {1 , 1};
            int rnaOR[] = {1, 1};
            int rnaXOR[][] = {
                {1,1},
                {-1,1},   
            };
            
            System.out.printf("\n\nAND");
            prodPunto(rnaAND, entrada, 1.5);
            System.out.printf("\n\nOR");
            prodPunto(rnaOR, entrada, 0.9);
            System.out.printf("\n\nXOR");
            prodPuntoXor(rnaXOR, entrada);
            
            
        }

        public static void prodPunto(int rna[],int entrada[][], double umbral){
            for (int i = 0; i < entrada.length; i++){
                int suma = 0;
                suma += rna[0] * entrada[i][0] + rna[1] * entrada[i][1];
                
                System.out.printf("\n| %d | %d | %d |"
                        , entrada[i][0], entrada[i][1], (suma >= umbral)? 1 : 0);
            }
        }
        
        public static void prodPuntoXor(int rna[][],int entrada[][]){
            
            for (int i = 0; i < entrada.length; i++){
                    int suma = 0;
                    int salida1 = 0;
                    int salida2 = 0;
                    
                    suma += rna[0][0] * entrada[i][0] + rna[0][1] * entrada[i][1];
                    
                    if(suma >= 1.5)
                        salida1 = -1;
                    if(suma >= 0.9)
                        salida2 = 1;
                    
                    suma = salida1 + salida2;
                    
                    System.out.printf("\n| %d | %d | %d |"
                            , entrada[i][0], entrada[i][1], (suma >= 0.5)? 1 : 0);
            }
        }
    }
