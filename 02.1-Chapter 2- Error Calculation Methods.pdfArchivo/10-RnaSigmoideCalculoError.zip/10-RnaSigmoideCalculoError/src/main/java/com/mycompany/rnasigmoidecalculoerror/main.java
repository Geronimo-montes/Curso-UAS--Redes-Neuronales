/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.rnasigmoidecalculoerror;

import matrix.Matrix;
import matrix.MatrixMath;

/**
 *
 * @author geronimo
 */
public class main {

  public static void main(String[] args) {
    /* Matrix Class para AND OR XOR */
    double entrada[][] = {
      {1, 1, 1},
      {1, 0, 1},
      {0, 1, 1},
      {0, 0, 1},};
    /* Para XOR */
    double rnaXOR[][] = {
      {3.24981438080398, 3.25025504991178, -4.96015949448697},
      {5.30923599934405, 5.31143768673604, -2.09333198955935},
      {-6.95364520156203, 6.46735810745298, -2.88923608790176}
    };

    Matrix _entrada = new Matrix(entrada);
    Matrix _rnaXor = new Matrix(rnaXOR);

    System.out.printf("\n\nXOR con Matrix");
    imprimirXor(_entrada, _rnaXor);
  }

  public static void imprimirXor(Matrix _entrada, Matrix _rna) {
    try {
      double n1, n2, salida = 0;
      double _prodPunto;
      double[] salidaDeseada = {0, 1, 1, 0}, error = new double[4];
      double MSE = 0, ESS = 0, RMS = 0;

      /**Productos puntos */
      for (int i = 0; i < _entrada.getRows(); i++) {
        n1 = activacionSigmoide(
            MatrixMath.dotProduct(
                _rna.getRow(0), _entrada.getRow(i)
            ));

        n2 = activacionSigmoide(
            MatrixMath.dotProduct(
                _rna.getRow(1), _entrada.getRow(i)
            ));

        salida = activacionSigmoide(
            n1 * _rna.get(2, 0)
            + n2 * _rna.get(2, 1)
            + 1 * _rna.get(2, 2)
        );

        error[i] = salidaDeseada[i] - salida;

        System.out.printf("\n| %1.0f | %1.0f | %1.0f | %1.10f | %1.10f |",
            _entrada.get(i, 0),
            _entrada.get(i, 1),
            salidaDeseada[i],
            salida,
            error[i]
        );
      }

      for (int i = 0; i < 4; i++) {
        MSE += Math.pow(error[i], 2);
        ESS += Math.pow(error[i], 2);
      }

      MSE /= 4;
      ESS /= 2;
      RMS = Math.sqrt(MSE);

      System.out.printf("\n\n|  MSE |      ESS       |  RMS |\n--------------------------------\n| %3.12f%% | %1.12f | %3.12f%% |",
          MSE *100,
          ESS,
          RMS * 100
      );
    } catch (Exception e) {
      System.out.println("\nError: " + e.getMessage());
    }
  }

  public static double activacionSigmoide(double prodPunto) {
    return (1 / (1 + Math.exp(-1 * prodPunto)));
  }

  public static void imprimir(Matrix a) {
    for (int row = 0; row < a.getRows(); row++) {
      for (int col = 0; col < a.getCols(); col++) {
        System.out.printf(" %2.2f ", a.get(row, col));
        if (col == a.getCols() - 1) {
          System.out.print("\n");
        }
      }
    }
  }
}
