/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.redhopfiel;

import java.util.Scanner;
import java.util.Arrays;
import com.heatonresearch.book.introneuralnet.neural.matrix.BiPolarUtil;
import com.heatonresearch.book.introneuralnet.neural.matrix.Matrix;
import com.heatonresearch.book.introneuralnet.neural.matrix.MatrixMath;

/**
 *
 * @author geronimo
 */
public class main {

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    Scanner leer = new Scanner(System.in);
    int length;
    String patron, res = "s";
    boolean[] patronBooleano;
    Matrix patronMatrix;

    try {
      System.out.println("Dijite la lonjitud del patron: ");
      length = leer.nextInt();
      /*Inicializacion de la matriz con pesos en 0*/
      Matrix rna = new Matrix(length, length);

      do {
        System.out.println("Patron para entrenar la red: ");
        patron = leer.next();

        /*Validacion del patron de netrada length y dijitos validos*/
        patronBooleano = validarPatron(patron, length);
        /*Convertir array binario a bipolar*/
        patronMatrix = Matrix.createRowMatrix(BiPolarUtil.bipolar2double(patronBooleano));
        /*Multiplicar por traspuesta*/
        patronMatrix = MatrixMath.multiply(MatrixMath.transpose(patronMatrix), patronMatrix);
        /*Ajustar diagonal a 0*/
        patronMatrix = MatrixMath.subtract(patronMatrix, MatrixMath.identity(length));
        /*Entrenando a la red para reconocer un patron nuevo*/
        rna = MatrixMath.add(rna, patronMatrix);
        imprimir(rna);

        System.out.println("Entrenar para otro patron? (s/n)");
        res = leer.next();
      } while (res.equals("s"));

      do {
        /*Testeo de la rna*/
        boolean[] patronTest = new boolean[length];
        System.out.println("Introducir patron de prueba: ");
        patron = leer.next();
        /*Patron a testear*/
        patronBooleano = validarPatron(patron, length);
        patronMatrix = Matrix.createColumnMatrix(
            BiPolarUtil.bipolar2double(patronBooleano)
        );
        /*Producto punto del patron por el renglon de la matriz >0 1 <=0 0*/
        for (int i = 0; i < rna.getRows(); i++) {
          patronTest[i] = MatrixMath.dotProduct(patronMatrix, rna.getRow(i)) > 0;
        }
        /*Impresion resultados ¿Reconocio el patron?*/
        System.out.println(patron
            + ((Arrays.equals(patronBooleano, patronTest)
            || (Arrays.equals(patronBooleano, invArray(patronTest))))
            ? "\tPatron reconocido" : "\tPatron desconocido")
        );
      } while (true);
    } catch (Exception e) {
      System.err.println(e.getMessage());
    }
  }

  public static boolean[] validarPatron(String patron, int length) throws Exception {
    boolean[] vector = new boolean[length];

    if (patron.length() != length) {
      throw new Exception("La longitud del patron no es la adecuada");
    }

    for (int i = 0; i < patron.length(); i++) {
      if (!patron.substring(i, i + 1).equals("0")
          && !patron.substring(i, i + 1).equals("1")) {
        throw new Exception("Dijito no binario: " + patron.substring(i, i + 1));
      }
      vector[i] = (patron.substring(i, i + 1).equals("0")) ? false : true;
    }
    return vector;
  }

  public static boolean[] invArray(boolean[] n) {
    boolean aux;
    for (int i = 0; i < n.length / 2; i++) {
      aux = n[i];
      n[i] = n[n.length - 1 - i];
      n[n.length - 1 - i] = aux;
    }
    return n;
  }

  public static void imprimir(Matrix a) {
    for (int row = 0; row < a.getRows(); row++) {
      for (int col = 0; col < a.getCols(); col++) {
        System.out.printf(" %2.0f ", a.get(row, col));
      }
      System.out.print("\n");
    }
  }

  public static void imprimir(boolean[] a) {
    for (int row = 0; row < a.length; row++) {
      System.out.printf(" %b ", a[row]);
    }
    System.out.print("\n");
  }

  public static void imprimir(double[] a) {
    for (int row = 0; row < a.length; row++) {
      System.out.printf(" %2.0f ", a[row]);
    }
    System.out.print("\n");
  }
}
