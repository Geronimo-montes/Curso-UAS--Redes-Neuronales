/**
 * Introduction to Neural Networks with Java, 2nd Edition
 * Copyright 2008 by Heaton Research, Inc.
 * http://www.heatonresearch.com/books/java-neural-2/
 *
 * ISBN13: 978-1-60439-008-7
 * ISBN:   1-60439-008-5
 *
 * This class is released under the:
 * GNU Lesser General Public License (LGPL)
 * http://www.gnu.org/copyleft/lesser.html
 */
package com.heatonresearch.book.introneuralnet.ch6.xor;

import com.heatonresearch.book.introneuralnet.neural.feedforward.FeedforwardLayer;
import com.heatonresearch.book.introneuralnet.neural.feedforward.FeedforwardNetwork;
import com.heatonresearch.book.introneuralnet.neural.feedforward.train.genetic.TrainingSetNeuralGeneticAlgorithm;
import com.heatonresearch.book.introneuralnet.neural.matrix.Matrix;

/**
 * Chapter 6: Training using a Genetic Algorithm
 *
 * XOR: Learn the XOR pattern with a feedforward neural network that uses a
 * genetic algorithm.
 *
 * @author Jeff Heaton
 * @version 2.1
 */
public class GeneticXOR {

  public static double INPUT_C1_C2[][] = {
    {-0.07, 0.94, -0.26,},
    {0.22, 0.46, 0.5,},
    {0.35, 0.5, 0.36,},
    {-0.46, 0.1, -0.4}
  };

  public static double INPUT_C2_C3[] = {
    -0.22, 0.58, 0.5, 0.78
  };

  public static Matrix INPUT_C1_C2_MATRIX = new Matrix(INPUT_C1_C2);
  public static Matrix INPUT_C2_C3_MATRIX = Matrix.createColumnMatrix(INPUT_C2_C3);

  public static double XOR_INPUT[][] = {
    {0.0, 0.0, 0.0},
    {1.0, 1.0, 1.0},
    {0.0, 1.0, 0.0},
    {0.0, 0.43, 1.0},
    {1.0, 0.0, 0.0}
  };

  public static double XOR_IDEAL[][] = {
    {1.0},
    {0.0},
    {0.0},
    {1.0},
    {1.0}
  };

  public static void main(final String args[]) {
    FeedforwardNetwork network = new FeedforwardNetwork();
    network.addLayer(new FeedforwardLayer(3));
    network.addLayer(new FeedforwardLayer(3));
    network.addLayer(new FeedforwardLayer(1));
    network.reset(INPUT_C1_C2_MATRIX, INPUT_C2_C3_MATRIX);

    // train the neural network
    final TrainingSetNeuralGeneticAlgorithm train = new TrainingSetNeuralGeneticAlgorithm(
        network,
        //Reset : boolean
        //false : Deja los mismo valores para los pesos de conesxion  
        //true  : Mendiante el metodo reset establece pesoss aleatorios para
        //        las conexiones
        true,
        XOR_INPUT,
        XOR_IDEAL,
        5000, //PopulationSize
        0.1, //Porcentaje de mutacion
        0.25 //Porcentaje de corte
    );

    int epoch = 1;

    do {
      train.iteration();
      //System.out.println("Epoch #" + epoch + " Error:" + train.getError());
      System.out.printf("Epoch--->#%d Error--->%1.40f\n", epoch, train.getError());
      epoch++;
    } while ((epoch < 5000) && (train.getError() > 0.0006));

    network = train.getNetwork();

    // test the neural network
    System.out.println("Neural Network Results:");
    for (int i = 0; i < XOR_IDEAL.length; i++) {
      final double actual[] = network.computeOutputs(XOR_INPUT[i]);
      System.out.println(XOR_INPUT[i][0] + "," + XOR_INPUT[i][1]
          + ", actual=" + actual[0] + ",ideal=" + XOR_IDEAL[i][0]);
    }
  }
}
