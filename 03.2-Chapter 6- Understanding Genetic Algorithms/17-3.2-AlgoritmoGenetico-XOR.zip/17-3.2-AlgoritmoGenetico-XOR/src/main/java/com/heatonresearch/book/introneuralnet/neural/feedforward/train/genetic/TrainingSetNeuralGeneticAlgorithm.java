/**
 * Introduction to Neural Networks with Java, 2nd Edition
 * Copyright 2008 by Heaton Research, Inc.
 * http://www.heatonresearch.com/books/java-neural-2/
 *
 * ISBN13: 978-1-60439-008-7
 * ISBN:   1-60439-008-5
 *
 * This class is released under the:
 * GNU Lesser General Public License (LGPL)
 * http://www.gnu.org/copyleft/lesser.html
 */
package com.heatonresearch.book.introneuralnet.neural.feedforward.train.genetic;

import com.heatonresearch.book.introneuralnet.neural.exception.NeuralNetworkError;
import com.heatonresearch.book.introneuralnet.neural.feedforward.FeedforwardNetwork;

/**
 * TrainingSetNeuralGeneticAlgorithm: Implements a genetic algorithm that allows
 * a feedforward neural network to be trained using a genetic algorithm. This
 * algorithm is for a feed forward neural network. The neural network is trained
 * using training sets.
 *
 * @author Jeff Heaton
 * @version 2.1
 */
public class TrainingSetNeuralGeneticAlgorithm extends
    NeuralGeneticAlgorithm<TrainingSetNeuralGeneticAlgorithm> {

  protected double input[][];
  protected double ideal[][];

  public TrainingSetNeuralGeneticAlgorithm(
      final FeedforwardNetwork network,
      final boolean reset,
      final double input[][],
      final double ideal[][],
      final int populationSize,
      final double mutationPercent,
      final double percentToMate
  ) throws NeuralNetworkError {

    this.setMutationPercent(mutationPercent);
    this.setMatingPopulation(percentToMate * 2);
    this.setPopulationSize(populationSize);
    this.setPercentToMate(percentToMate);

    this.input = input;
    this.ideal = ideal;

    //Crea las cromosomas en el caso 5000 cromosomas
    setChromosomes(new TrainingSetNeuralChromosome[getPopulationSize()]);

    //5000 iteraciones y clona la red neuronal a acada cromosoma
    for (int i = 0; i < getChromosomes().length; i++) {
      //Clona la red
      final FeedforwardNetwork chromosomeNetwork
          = (FeedforwardNetwork) network.clone();

      //Reset : boolean
      //false : Deja los mismo valores para los pesos de conesxion  
      //true  : Mendiante el metodo reset establece pesoss aleatorios para
      //        las conexiones
      if (reset) {
        chromosomeNetwork.reset();
      }

      //Con la red clonada crea una cromosoma nueva
      final TrainingSetNeuralChromosome c
          = new TrainingSetNeuralChromosome(this, chromosomeNetwork);

      //Class: NEuralCromosome --> 
      //1.Convierto los pesos en un array lineal
      //2.Calcula del costo
      //2.1 El calculo del cosoto lo realiza la clase FeedforwardNetwork
      //2.2 El costo es representado con el error producidos
      c.updateGenes();

      //Seteo de la nueva cromosoma
      setChromosome(i, c);
    }
    sortChromosomes();
  }

  /**
   * Returns the root mean square error for a complet training set.
   *
   * @param len The length of a complete training set.
   * @return The current error for the neural network.
   * @throws NeuralNetworkException
   */
  public double getError() throws NeuralNetworkError {
    final FeedforwardNetwork network = this.getNetwork();
    return network.calculateError(this.input, this.ideal);
  }

  /**
   * @return the ideal
   */
  public double[][] getIdeal() {
    return this.ideal;
  }

  /**
   * @return the input
   */
  public double[][] getInput() {
    return this.input;
  }

}
