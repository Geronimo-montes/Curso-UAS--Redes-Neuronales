/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.rnasigmoide;

import matrix.Matrix;
import matrix.MatrixMath;

/**
 *
 * @author geronimoF
 */
public class main {

  public static void main(String[] args) {
    /* Matrix Class para AND OR XOR */
    double entrada[][] = {
      {0, 0, 1},
      {0, 1, 1},
      {1, 0, 1},
      {1, 1, 1}
    };
    /* Para AND*/
    double rnaAnd[] = {.3, .3, .1};
    /* Para OR */
    double rnaOr[] = {1, 1, .5};
    /* Para XOR */
    double rnaXOR[][] = {
      {1, .5, .1},
      {.1, .6, .1}
    };

    Matrix _entrada = new Matrix(entrada);
    Matrix _rnaAnd = Matrix.createRowMatrix(rnaAnd);
    Matrix _rnaOr = Matrix.createRowMatrix(rnaOr);
    Matrix _rnaXor = new Matrix(rnaXOR);

    System.out.printf("\n\nAND con Matrix");
    imprimirAndOr(_entrada, _rnaAnd);

    System.out.printf("\n\nOR con Matrix");
    imprimirAndOr(_entrada, _rnaOr);

    System.out.printf("\n\nXOR con Matrix");
    imprimirXor(_entrada, MatrixMath.transpose(_rnaXor));
  }

  public static void imprimirXor(Matrix _entrada, Matrix _rna) {
    try {
      double salidaCap2 = 0;
      Matrix res = MatrixMath.multiply(_entrada, _rna);

      for (int row = 0; row < res.getRows(); row++) {
        salidaCap2 = activacionSigmoide(
            //En viamos a la funcion de activacion los valores obtenidos
            //en la multiplicacion por sus pesos correspondientes
            (res.get(row, 0) * .5) //#1 nuerona 
            + (res.get(row, 1) * .5) //#2 nuerona
            + 1 * .5//neurona de sesgo ---> entrada | peso
        );

        System.out.printf("\n| %1.0f | %1.0f | %1.6f---->%1.6f |",
            _entrada.get(row, 0),
            _entrada.get(row, 1),
            salidaCap2,
            activacionSigmoide(salidaCap2)
        );
      }
    } catch (Exception e) {
      System.out.println("\nError: " + e.getMessage());
    }
  }

  public static void imprimirAndOr(Matrix _entrada, Matrix _rna) {
    double _prodPunto;

    try {
      for (int i = 0; i < _entrada.getRows(); i++) {
        _prodPunto = MatrixMath.dotProduct(_rna, _entrada.getRow(i));
        System.out.printf("\n| %1.0f | %1.0f | %2.6f---->%2.6f |",
            _entrada.get(i, 0),
            _entrada.get(i, 1),
            _prodPunto,
            activacionSigmoide(_prodPunto));
      }
    } catch (Exception e) {
      System.out.println("\nError: " + e.getMessage());
    }
  }

  public static double activacionSigmoide(double prodPunto) {
    return (1 / (1 + Math.exp(-1 * prodPunto)));
  }
}
